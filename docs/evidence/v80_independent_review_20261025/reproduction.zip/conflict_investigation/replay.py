import os, sys, json, pathlib, importlib.util, traceback, copy, types
from datetime import datetime, timezone
from zoneinfo import ZoneInfo
import pandas as pd
import numpy as np
import ast, io
from urllib.parse import urlparse, parse_qs

ROOT = pathlib.Path(__file__).resolve().parent
PREV = ROOT.parent / 'source_validation'
MAN = json.loads((ROOT/'source_manifest.json').read_text(encoding='utf-8'))
for _key,_item in MAN.items():
    _item['copy']=str(ROOT/'isolated'/_key/pathlib.Path(_item['copy']).name)
STAMP = datetime(2026,10,24,0,15,tzinfo=timezone.utc)
class FrozenDatetime(datetime):
    @classmethod
    def now(cls,tz=None):
        return STAMP.astimezone(tz).replace(tzinfo=tz) if tz else STAMP.replace(tzinfo=None)
    @classmethod
    def today(cls): return cls.now()

def load(key):
    p=pathlib.Path(MAN[key]['copy']); os.chdir(p.parent)
    spec=importlib.util.spec_from_file_location('isolated_'+key,p)
    mod=importlib.util.module_from_spec(spec);sys.modules[spec.name]=mod;spec.loader.exec_module(mod)
    mod.datetime=FrozenDatetime
    real_time=mod.time
    mod.time=types.SimpleNamespace(**{k:getattr(real_time,k) for k in dir(real_time) if not k.startswith('__')})
    mod.time.time=lambda:STAMP.timestamp();mod.time.sleep=lambda *_:None
    return mod

def yahoo(symbol, mod=None):
    v=json.loads((PREV/'tiingo_authenticated/yahoo_current'/f'{symbol}.json').read_text(encoding='utf-8'))
    r=v['chart']['result'][0];q=r['indicators']['quote'][0]
    ix = mod.yahoo_index_from_timestamps(r['timestamp'],r,symbol=symbol) if mod else pd.to_datetime(r['timestamp'],unit='s',utc=True).tz_convert('UTC' if symbol=='BTC-USD' else 'America/New_York').tz_localize(None).normalize()
    f=pd.DataFrame({**q,'adj_close':r['indicators']['adjclose'][0]['adjclose']},index=ix).apply(pd.to_numeric,errors='coerce').sort_index()
    return f.loc[:'2026-10-23']

def change_kmlm(f,mode):
    f=f.copy();p=f.loc['2022-12-27'];e=f.loc['2022-12-28']
    observed=(p.adj_close/p.close)/(e.adj_close/e.close)
    desired=1-4.0377/p.close if mode=='missing_distribution_only' else e.close/(e.close+4.0377)
    f.loc[f.index<pd.Timestamp('2022-12-28'),'adj_close']*=desired/observed
    return f

def compare(a,b,label):
    out={'label':label,'start':str(a.index.min().date()),'end':str(a.index.max().date()),'rows':len(a),'columns':list(a.columns),'latest_before':{},'latest_after':{},'changed_columns':{}}
    for col in a.columns.intersection(b.columns):
        x,y=a[col],b[col]
        if pd.api.types.is_numeric_dtype(x):
            hit=~np.isclose(x.astype(float),y.astype(float),atol=1e-10,rtol=1e-10,equal_nan=True)
        else:hit=(x.astype(str)!=y.astype(str)).values
        dates=a.index[hit]
        if len(dates):out['changed_columns'][col]={'count':len(dates),'first':str(dates.min().date()),'last':str(dates.max().date()),'max_abs_difference':float((x-y).abs().max()) if pd.api.types.is_numeric_dtype(x) else None}
        if not isinstance(x.iloc[-1],(dict,list,np.ndarray)):
            out['latest_before'][col]=str(x.iloc[-1]);out['latest_after'][col]=str(y.iloc[-1])
    for navcol in ['nav','strategy_nav','combo_nav']:
        if navcol in a:
            out['terminal_nav_ratio_delta']=float(b[navcol].iloc[-1]/a[navcol].iloc[-1]-1);break
    return out

def saveframe(f,name):
    p=ROOT/'replay_frames';p.mkdir(exist_ok=True)
    f.to_csv(p/(name+'.csv'),encoding='utf-8-sig',index_label='date')

def v16():
    m=load('v16'); frames={s:yahoo(s,m) for s in list(m._v15_unique_fetch_configs())+[m.BIL_SYMBOL]}
    validity={}
    for s,f in frames.items():
        try:m.validate_ohlcv(f,s);validity[s]='PASS'
        except Exception as e:validity[s]=str(e)
    (ROOT/'v16_input_validation.json').write_text(json.dumps(validity,indent=2),encoding='utf-8')
    bad={s:e for s,e in validity.items() if e!='PASS'}
    if bad:raise RuntimeError('Strict input validation failed '+json.dumps(bad))
    def run(mode):
        m._V15_ALL_CURVES_CACHE.clear()
        def fetch(s,**kwargs):
            f=frames[s].copy()
            if s=='KMLM' and mode!='baseline':f=change_kmlm(f,mode)
            m.validate_ohlcv(f,s)
            return f,'Yahoo archived real response; '+mode
        m.fetch_yahoo_ohlcv=fetch
        return m.load_v15_state(include_realtime=False,signal_availability_mode=False)
    base=run('baseline');repeat=run('baseline')
    pd.testing.assert_frame_equal(base[2],repeat[2])
    result={'strict_input_validation':validity,'baseline_repeat':'exact dataframe equal','comparisons':[]}
    for mode in ['missing_distribution_only','cash_total_return_event']:
        alt=run(mode)
        kmlmkey=next(c.key for c in m.V14_ETF_CONFIGS if m.yahoo_symbol(c)=='KMLM')
        for label,x,y in [('V16 meta',base[2],alt[2])]+[(f'V16 {fam} portfolio',base[1][fam],alt[1][fam]) for fam in base[1]]+[(f'V16 {fam} KMLM',base[0][fam][kmlmkey],alt[0][fam][kmlmkey]) for fam in base[0] if kmlmkey in base[0][fam]]:
            result['comparisons'].append({'scenario':mode,**compare(x,y,label)})
            safe=label.replace(' ','_');saveframe(x,safe+'_baseline');saveframe(y,safe+'_'+mode)
    return result

def sina(symbol):
    f=pd.DataFrame(json.loads((PREV/'sina_shadow'/f'{symbol}.json').read_text(encoding='utf-8')))
    f.index=pd.to_datetime(f.pop('day')).dt.normalize();return f.apply(pd.to_numeric,errors='coerce').sort_index()

def windbad():
    v=json.loads((PREV/'wind_authenticated/zz1000_full_kline_parsed.json').read_text(encoding='utf-8'))
    d=json.loads(v['result']['content'][0]['text'])['data'];a=pd.DataFrame(d['rows'],columns=[x['name'] for x in d['columns']]); row=a.iloc[-1]
    return {dst:float(row[src]) for src,dst in [('OPEN','open'),('MATCH','close'),('HIGH','high'),('LOW','low'),('VOLUME','volume')]}

def cn6():
    m=load('cn6');frames={c.key:sina(c.sina_symbol) for c in m.SLEEVES}
    for c in m.SLEEVES:m.validate_ohlcv_for_sleeve(frames[c.key],c)
    key=next(c.key for c in m.SLEEVES if c.sina_symbol=='sh000852');cfg=next(c for c in m.SLEEVES if c.key==key)
    def run(bad=False):
        def fetch(c):
            f=frames[c.key].copy()
            if bad and c.key==key:
                for col,val in windbad().items():f.loc['2026-10-21',col]=val
            m.validate_ohlcv_for_sleeve(f,c)
            return f,'frozen Sina / official CSI adjudicated' if not bad else 'counterfactual single Wind bad bar'
        m.fetch_ohlcv_for_sleeve=fetch
        curves,sources,errors=m.load_all_curves(include_realtime=False)
        return curves,m.build_combo(curves)
    b=run();repeat=run();pd.testing.assert_frame_equal(b[1],repeat[1]);alt=run(True)
    result={'baseline_repeat':'exact dataframe equal','comparisons':[compare(b[0][key],alt[0][key],'CN6 CSI1000'),compare(b[1],alt[1],'CN6 combo')]}
    try:m.validate_local_cache_freshness(frames[key].loc[:'2026-10-21'],cfg);result['truncated_tail_gate']='ACCEPTED'
    except Exception as e:result['truncated_tail_gate']=str(e)
    for label,x,y in [('CN6_CSI1000',b[0][key],alt[0][key]),('CN6_combo',b[1],alt[1])]:saveframe(x,label+'_baseline');saveframe(y,label+'_bad_Wind_bar')
    return result

def v80():
    m=load('v80')
    tree=ast.parse(pathlib.Path(MAN['v80']['copy']).read_text(encoding='utf-8-sig'))
    cls=next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name=='CombinedStrategyBase')
    fetch=next(n for n in cls.body if isinstance(n,ast.FunctionDef) and n.name=='_fetch_data')
    # Execute the exact US acquisition/validation/transformation statements from
    # the current formal function, leaving all strategy and price guards intact.
    body=[copy.deepcopy(n) for n in fetch.body if 13534<=n.lineno<=13657]
    body.append(ast.parse('return us_rot_close, us_prod_daily').body[0])
    fn=ast.FunctionDef(name='_isolated_us_fetch',args=ast.arguments(posonlyargs=[],args=[ast.arg(arg='self'),ast.arg(arg='msg'),ast.arg(arg='include_us_live_snapshot')],kwonlyargs=[],kw_defaults=[],defaults=[ast.Constant(False)]),body=body,decorator_list=[])
    exec(compile(ast.fix_missing_locations(ast.Module(body=[fn],type_ignores=[])),'<exact formal US fetch statements>','exec'),m.__dict__)
    mode='baseline'
    class Response:
        status_code=200
        def __init__(self,v): self.v=v
        def json(self): return self.v
        def raise_for_status(self):pass
    def get(url,*args,**kw):
        if '/finance/chart/' not in url:raise RuntimeError('Unarchived HTTP forbidden in replay: '+url.split('?')[0])
        symbol=urlparse(url).path.rsplit('/',1)[1]
        p=PREV/'tiingo_authenticated/yahoo_current'/f'{symbol}.json'
        if not p.exists():p=ROOT/'independent'/f'{symbol}.json'
        v=json.loads(p.read_text(encoding='utf-8'));r=v['chart']['result'][0]
        if symbol=='KMLM' and mode!='baseline':
            f=change_kmlm(yahoo(symbol),mode);r['indicators']['adjclose'][0]['adjclose']=f.adj_close.tolist()
        start=int(parse_qs(urlparse(url).query).get('period1',['0'])[0]);end=int(parse_qs(urlparse(url).query).get('period2',[str(int(STAMP.timestamp()))])[0])
        ix=[i for i,t in enumerate(r['timestamp']) if start<=t<end and datetime.fromtimestamp(t,timezone.utc).date()<=STAMP.date()]
        r['timestamp']=[r['timestamp'][i] for i in ix]
        for q in r['indicators']['quote']+r['indicators']['adjclose']:
            for k,a in q.items():q[k]=[a[i] for i in ix]
        return Response(v)
    m._session.get=get
    # All inputs must be satisfied by archived real data; no live fallback.
    m.requests.get=lambda *a,**k: (_ for _ in ()).throw(RuntimeError('Live HTTP forbidden in frozen replay'))
    results={}
    for mode in ['baseline','missing_distribution_only','cash_total_return_event']:
        bot=m.CombinedStrategyV80();log=io.StringIO();rot,prod=m._isolated_us_fetch(bot,log,False)
        (ROOT/f'v80_{mode}_validation_log.txt').write_text(log.getvalue(),encoding='utf-8')
        b79=m._run_v80_subb_variants(rot,us_open=bot._us_open,strict_open_execution=True)
        b78=b79.attrs['v80_b78']
        monthly=prod.resample('ME').last()
        if monthly.index[-1].to_period('M')==pd.Timestamp(STAMP.astimezone(ZoneInfo('Asia/Shanghai')).date()).to_period('M'):monthly=monthly.iloc[:-1]
        sa=m.make_abs_mom_signals(monthly,m.PROD_ABS_MOM_LB);sb=m.make_sma_signals(monthly,m.PROD_SMA_WINDOW,m.PROD_SMA_BAND)
        if not m.PROD_USE_TIMING:sa[:]=1.;sb=sa.copy()
        ret=monthly.pct_change(fill_method=None).dropna(how='all');cash=ret[m.PROD_CASH]
        nav,detail=m.simulate_prod_btc_phased(ret,sa,cash,m.PROD_REBAL_MONTH,sig_b=sb,blend_a=m.PROD_BLEND_A,commission=m.PROD_COMMISSION)
        results[mode]={'B7.8':b78,'B7.9':b79,'Sub-C':nav.to_frame('nav') if isinstance(nav,pd.Series) else nav,'Sub-C signals A':sa,'Sub-C signals B':sb}
        if isinstance(detail,pd.DataFrame):results[mode]['Sub-C detail']=detail
        for label,f in results[mode].items():saveframe(f,'V80_'+label.replace(' ','_')+'_'+mode)
        print('V80 scenario completed',mode,flush=True)
    return {'scope':'Formal US component functions and exact formal US fetch/validation statements; no total V80 combined result asserted','comparisons':[{'scenario':mode,**compare(results['baseline'][label],results[mode][label],'V80 '+label)} for mode in ['missing_distribution_only','cash_total_return_event'] for label in results[mode]]}

def v80dk():
    m=load('v80')
    syms={'DK_ZZ1000':'sh000852','DK_SZ50':'sh000016','DK_HS300':'sh000300','DK_ZZ500':'sh000905','DK_CYB':'sz399006'}
    frames={k:sina(s)[['close']].rename(columns={'close':k}) for k,s in syms.items()}
    dk=m._build_cn_dk_close_frame(frames)
    m._assert_cn_raw_prices_fresh(frames,m.CN_DK_COLS,pd.Timestamp('2026-10-23'),'isolated ADK replay')
    cn=pd.DataFrame(index=dk.index) # Current CN_DK_INDICES declares all five sources='dk'; unused by this formal function.
    base=m.run_v80_adk_new_only(cn,dk);repeat=m.run_v80_adk_new_only(cn,dk)
    pd.testing.assert_frame_equal(base,repeat)
    bad=dk.copy();bad.loc['2026-10-21','DK_ZZ1000']=windbad()['close']
    alt=m.run_v80_adk_new_only(cn,bad)
    saveframe(base,'V80_ADK_baseline');saveframe(alt,'V80_ADK_bad_Wind_bar')
    return {'scope':'Current formal single ADK component, all ten pairs, score-hot, same cost settings; all five declared source fields come from DK data','baseline_repeat':'exact dataframe equal','comparisons':[compare(base,alt,'V80 ADK')]}

def csi(code):
    p=ROOT/'independent'/f'csi_{code}_full.json';d=json.loads(p.read_text(encoding='utf-8'))['data']
    f=pd.DataFrame(d);f.index=pd.to_datetime(f.pop('tradeDate'),format='%Y%m%d');return f.sort_index()

def v80a():
    m=load('v80')
    syms={'0.399006':'sz399006','1.000016':'sh000016','1.000852':'sh000852','1.000905':'sh000905'}
    raw={k:sina(s)[['close']] for k,s in syms.items()}
    raw['1.930955']=csi('930955')[['close']].astype(float)
    cn=m._build_cn_stock_close_frame(raw)
    bond=csi('H11077')[['close']].astype(float);cn[m.CN_BOND_CODE]=bond.close.reindex(cn.index)
    if cn.isna().any().any():raise RuntimeError('Missing formal stock or bond dates')
    m._assert_cn_raw_prices_fresh(raw,m.CN_STOCK_CODES,pd.Timestamp('2026-10-23'),'isolated Sub-A')
    amounts={code:csi(code)[['tradingValue']].rename(columns={'tradingValue':'amount'}).astype(float) for code in ['932000','000016']}
    d=json.loads((ROOT/'independent/sohu_cyb.json').read_text(encoding='utf-8'))[0]['hq']
    cyb=pd.DataFrame({'date':[r[0] for r in d],'amount':[float(r[8]) for r in d]});cyb.index=pd.to_datetime(cyb.pop('date'));amounts['399006']=cyb.sort_index()
    def amt(secid,*args,**kw):return amounts[secid.split('.')[-1]].copy(),'archived issuer CSI amount / Sohu CYB amount'
    m._fetch_cn_amount_with_fallback=amt
    signal,feature=m._load_suba_volume_signal(expected_date=pd.Timestamp('2026-10-23'))
    feature=m._annotate_rule_freshness(feature,expected_date=pd.Timestamp('2026-10-23'),rule_key='suba_volume')
    saveframe(feature,'V80_Sub-A_volume_features')
    def run(frame):
        r=m.run_cn_strategy(frame,m.CN_EQUITY_CODES)
        if m._suba_volume_feature_has_unresolved(feature,r.index):raise RuntimeError('Formal Sub-A volume overlay unresolved')
        return m._apply_suba_volume_overlay_policy(r,frame,signal,feature,allow_unresolved_suba_volume=False)
    base_price=m.run_cn_strategy(cn,m.CN_EQUITY_CODES)
    bad=cn.copy();bad.loc['2026-10-21','1.000852']=windbad()['close'];alt_price=m.run_cn_strategy(bad,m.CN_EQUITY_CODES)
    unresolved=feature.combined_unresolved.reindex(base_price.index).fillna(True).astype(bool)
    if unresolved.any():
        # Preserve full-history rejection. Current signals can still be checked
        # on fully observed recent risk inputs, without certifying older NAV.
        first_valid=unresolved[unresolved].index.max()+pd.Timedelta(days=1)
        recent_base=base_price.loc[first_valid:];recent_alt=alt_price.loc[first_valid:]
        if m._suba_volume_feature_has_unresolved(feature,recent_base.index):raise RuntimeError('Recent Sub-A risk inputs still unresolved')
        rb=m._apply_suba_volume_overlay_policy(recent_base,cn,signal,feature,allow_unresolved_suba_volume=False)
        ra=m._apply_suba_volume_overlay_policy(recent_alt,bad,signal,feature,allow_unresolved_suba_volume=False)
        saveframe(rb,'V80_Sub-A_recent_diagnostic_baseline');saveframe(ra,'V80_Sub-A_recent_diagnostic_bad_Wind_bar')
        return {'full_history_status':'BLOCKED, strict original guard retained','reason':'Sohu CYB amount missing on 2018-12-14; affected required MA window through 2019-01-17. Wind historic volume/amount convention differs from Sohu; not spliced.','unknown_dates':unresolved[unresolved].index.strftime('%Y-%m-%d').tolist(),'scope':'Current target and recent price sensitivity only; no full Sub-A or full V80 combined performance certified','comparisons':[compare(rb,ra,'V80 Sub-A recent diagnostic')]}
    base=run(cn);repeat=run(cn);pd.testing.assert_frame_equal(base,repeat);alt=run(bad)
    saveframe(base,'V80_Sub-A_baseline');saveframe(alt,'V80_Sub-A_bad_Wind_bar')
    return {'scope':'Current formal Sub-A with strict volume overlay','baseline_repeat':'exact dataframe equal','comparisons':[compare(base,alt,'V80 Sub-A')]}

if __name__=='__main__':
    for name in sys.argv[1:] or ['v16','cn6']:
        try:
            val=globals()[name]();(ROOT/f'{name}_result.json').write_text(json.dumps(val,ensure_ascii=False,indent=2,default=str),encoding='utf-8');print(name,'SUCCESS',flush=True)
        except Exception:
            error=traceback.format_exc();(ROOT/f'{name}_error.txt').write_text(error,encoding='utf-8');print(name,error,flush=True)
