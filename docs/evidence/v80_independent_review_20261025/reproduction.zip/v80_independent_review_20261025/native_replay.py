"""Run the actual candidate query entrypoints on original UNREPAIRED responses."""
import pathlib,sys,json,hashlib,copy,types,io,pickle,traceback,warnings
from urllib.parse import urlparse,parse_qs
import pandas as pd
import numpy as np
import requests

ROOT=pathlib.Path(__file__).resolve().parent
PREV=ROOT.parent/'conflict_investigation'
SOURCE=ROOT.parent/'source_validation'
sys.path.insert(0,str(PREV));import replay
MAN=json.loads((PREV/'source_manifest.json').read_text(encoding='utf-8'))

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads(p.read_text(encoding='utf-8'))
def jsonable(x):
    if isinstance(x,dict):return {str(k):jsonable(v) for k,v in x.items()}
    if isinstance(x,(list,tuple)):return [jsonable(v) for v in x]
    if isinstance(x,np.generic):return x.item()
    return x

def verified_gap():
    d=read(ROOT/'independent/cni_cyb_overlap.json')['data']
    f=pd.DataFrame(d['data'],columns=d['item'])
    f.index=pd.to_datetime(f.timestamp,unit='ms',utc=True).dt.tz_convert('Asia/Shanghai').dt.tz_localize(None).dt.normalize()
    old=read(PREV/'independent/sohu_cyb.json')
    rows={r[0]:r for r in old[0]['hq']}
    overlap=[]
    for day,row in f.iterrows():
        key=str(day.date())
        if key in rows:
            sv=float(rows[key][8])*10000
            err=sv/float(row.amount)-1
            assert abs(err)<2e-7,(key,sv,float(row.amount))
            assert abs(float(rows[key][2])-float(row.close))<.011
            overlap.append({'date':key,'cni_amount_yuan':float(row.amount),'sohu_amount_yuan':sv,'relative_error':err})
    assert len(overlap)==8
    target=f.loc['2018-12-14'];assert '2018-12-14' not in rows
    patch=['2018-12-14',str(target.open),str(target.close),str(target.chg),str(target.percent*100)+'%',str(target.low),str(target.high),str(target.volume/100),str(target.amount/10000),'-']
    old[0]['hq'].append(patch);old[0]['hq'].sort(key=lambda r:r[0],reverse=True)
    proof={'index':'399006','field':'constituent aggregate amount','missing_date':'2018-12-14','timezone':'source Unix milliseconds -> Asia/Shanghai trading day','cni_amount_yuan':float(target.amount),'sohu_unit_wanyuan':float(target.amount/10000),'overlap':overlap,'patch_rows':1,'price_and_strategy_parameters_changed':False}
    (ROOT/'gap_verification.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2),encoding='utf-8')
    return old,proof

class Response:
    status_code=200
    def __init__(self,data):self.data=data;self.text=json.dumps(data,ensure_ascii=False);self.content=self.text.encode()
    def json(self):return copy.deepcopy(self.data)
    def raise_for_status(self):pass

def main(mode):
    folder=ROOT/mode;folder.mkdir(exist_ok=True)
    copied=ROOT/'isolated'/mode/'v80';copied.mkdir(parents=True,exist_ok=True)
    name = 'mnt_bot V 8.0 plus.py'
    candidate = ROOT/('before' if mode == 'baseline' else 'after')/name
    expected = sha(candidate)
    if mode == 'baseline':
        assert expected == 'd4bcc51af3725686e19725dc253525fa8d483e0884cee9a033d423fd4d6438c9'
    target = copied/name
    target.write_bytes(candidate.read_bytes())
    replay.MAN['v80']['copy']=str(target)
    m=replay.load('v80');warnings.filterwarnings('ignore',category=pd.errors.PerformanceWarning)
    patched,proof=verified_gap();transport=[]
    def get(url,*args,**kw):
        if kw.get('params'):
            from urllib.parse import urlencode
            url+=('&' if '?' in url else '?')+urlencode(kw['params'])
        q=parse_qs(urlparse(url).query);path=urlparse(url).path
        if '/finance/chart/' in path:
            symbol=path.rsplit('/',1)[1]
            p=SOURCE/'tiingo_authenticated/yahoo_current'/f'{symbol}.json'
            if not p.exists():p=PREV/'independent'/f'{symbol}.json'
            if not p.exists():raise requests.exceptions.ConnectionError('No frozen Yahoo fixture: '+symbol)
            v=read(p);r=v['chart']['result'][0]
            lo=int(q.get('period1',['0'])[0]);hi=min(int(q.get('period2',[str(int(replay.STAMP.timestamp()))])[0]),int(replay.STAMP.timestamp()))
            ix=[i for i,t in enumerate(r['timestamp']) if lo<=t<hi]
            r['timestamp']=[r['timestamp'][i] for i in ix]
            for b in r['indicators']['quote']+r['indicators']['adjclose']:
                for k,a in b.items():b[k]=[a[i] for i in ix]
            transport.append({'kind':'Yahoo','symbol':symbol,'rows':len(ix),'fixture_sha256':sha(p),'harness_kmlm_patch':False})
            return Response(v)
        if 'CN_MarketData.getKLineData' in path:
            symbol=q.get('symbol',[''])[0];p=SOURCE/'sina_shadow'/f'{symbol}.json'
            if not p.exists():raise requests.exceptions.ConnectionError('No frozen Sina fixture: '+symbol)
            transport.append({'kind':'Sina','symbol':symbol,'fixture_sha256':sha(p)})
            return Response(read(p))
        if 'csindex-home/perf/index-perf' in path:
            code=q.get('indexCode',[''])[0];p=PREV/'independent'/f'csi_{code}_full.json'
            if not p.exists():raise requests.exceptions.ConnectionError('No frozen CSI fixture: '+code)
            transport.append({'kind':'CSI official','symbol':code,'fixture_sha256':sha(p)})
            return Response(read(p))
        if 'csindex.com.cn/indices/index-detail/' in url:return Response({})
        if 'q.stock.sohu.com/hisHq' in url and q.get('code',[''])[0]=='zs_399006':
            transport.append({'kind':'Original unfilled Sohu response','symbol':'399006','harness_amount_patch':False})
            return Response(read(PREV/'independent/sohu_cyb.json'))
        raise requests.exceptions.ConnectionError('Live HTTP disabled; no matching real archive: '+url.split('?')[0])
    m._session.get=get
    requests.sessions.Session.get=lambda self,url,*a,**kw:get(url,*a,**kw)
    requests.get=get

    class Message:
        def __init__(self):self.buf=io.StringIO();self.suffix='performance'
        def __enter__(self):return self
        def __exit__(self,*_):pass
        def write(self,text):self.buf.write(str(text))
        def attach_file(self,name,contents,**kw):
            safe=pathlib.Path(name).name
            if hasattr(contents,'getvalue'):contents=contents.getvalue()
            (folder/safe).write_bytes(contents)
    msg=Message();m._sm=lambda:msg
    bot=m.CombinedStrategyV80();capture={}
    original_fetch=bot._cached_fetch_data
    def fetch(*args,**kw):
        out=original_fetch(*args,**kw);capture['inputs']=out;capture['us_open']=bot._us_open
        return out
    bot._cached_fetch_data=fetch
    original_run=bot._cached_run_strategies
    def run(*args,**kw):
        out=original_run(*args,**kw)
        if not kw.get('allow_unresolved_suba_volume',False):capture['strategies']=out
        return out
    bot._cached_run_strategies=run
    origexcel=m.generate_performance_excel
    def excel(*args,**kw):
        capture['official_metrics']=copy.deepcopy(args[1]);capture['official_standard_windows']=copy.deepcopy(kw.get('standard_windows'));capture['report_context']=copy.deepcopy(kw.get('report_context'));capture['official_rebalances']=copy.deepcopy(args[3])
        return origexcel(*args,**kw)
    m.generate_performance_excel=excel
    print('START formal performance handler',mode,flush=True)
    bot._handle_performance('表现 全历史',_forced_range=(pd.Timestamp('2003-01-01'),pd.Timestamp('2026-10-23')))
    (folder/'正式绩效查询.txt').write_text(msg.buf.getvalue(),encoding='utf-8-sig')
    assert 'official_metrics' in capture,'No formal performance result captured'
    print('PASS formal performance handler',mode,flush=True)
    cn,dk,rot,prod=capture['inputs'];strategies=capture['strategies']
    cr,dr,br,monthly,sa,sb,pnav,pdetail=strategies
    assert not cr.get('suba_volume_unresolved',pd.Series(True,index=cr.index)).any()
    snapshot=m._compute_subc_production_snapshot(prod,sa,sb,us_open=bot._us_open,strict_open_execution=True)
    subc=snapshot['scaled_return'] if m.PROD_VS_ENABLED else snapshot['raw_return']
    daily=m._v80_performance_daily_returns(cr['return'],dr['return'],br,subc,end_date=pd.Timestamp('2026-10-23'))
    capture['daily_returns']=daily;capture['subc_snapshot']=snapshot
    frames={'Sub-A':cr,'Sub-A-DK':dr,'B7.8':br.attrs['v80_b78'],'B7.9':br}
    for name,f in frames.items():f.to_csv(folder/(name+'_daily.csv'),encoding='utf-8-sig',index_label='date')
    pd.DataFrame(daily).to_csv(folder/'all_daily_returns.csv',encoding='utf-8-sig',index_label='date')
    nav=pd.DataFrame({k:(1+v).cumprod() for k,v in daily.items()});nav.to_csv(folder/'all_nav.csv',encoding='utf-8-sig',index_label='date')
    # The original handler's standard-window values must equal recomputation
    # from the same official return streams, including original start anchors.
    anchors=m._performance_initial_period_anchors(daily,cn,dk,rot,prod)
    windows=m._performance_standard_window_rows(daily,end_date=pd.Timestamp('2026-10-23'),first_period_starts=anchors)
    assert json.dumps(windows,default=str,sort_keys=True)==json.dumps(capture['official_standard_windows'],default=str,sort_keys=True),'Helper vs official output mismatch'
    capture['formal_baseline_parity']='Exact standard-window metrics equal original performance handler output'
    capture['replay_flags']={k:v for k,v in m.__dict__.items() if k.isupper() and isinstance(v,(str,int,float,bool,dict,list,tuple)) and any(s in k for s in ['PERFORMANCE_COMBO','CN_SA_VOLUME','VOLREG','PROD_VS','PROD_GOLD_VS','COMMISSION','FINANCING','V80_SUBB','V80_ADK'])}
    print('PASS original-handler baseline parity',mode,flush=True)
    msg.buf=io.StringIO();bot._handle_signal()
    signal_text=msg.buf.getvalue();(folder/'正式信号查询.txt').write_text(signal_text,encoding='utf-8-sig')
    assert '信号查询失败' not in signal_text and '数据获取失败' not in signal_text
    capture['signal_data']=bot._compute_signal_data(cn,dk,rot,prod)
    capture['gap_patch']=proof;capture['transport']=transport
    import gzip
    with gzip.open(folder/'native_inputs.pkl.gz', 'wb') as h:
        pickle.dump({'inputs':capture['inputs'],'us_open':capture['us_open']},h,protocol=5)
    (folder/'run_summary.json').write_text(json.dumps(jsonable({k:capture[k] for k in ['official_metrics','official_standard_windows','report_context','formal_baseline_parity','gap_patch','replay_flags']}),ensure_ascii=False,indent=2,default=str),encoding='utf-8')
    (folder/'transport.json').write_text(json.dumps(transport,ensure_ascii=False,indent=2),encoding='utf-8')
    (folder/'source_sha256.txt').write_text(expected,encoding='ascii')
    print('SUCCESS',mode,'combined rows',len(daily['Combined']),'end',daily['Combined'].index[-1],flush=True)

if __name__=='__main__':
    mode=sys.argv[1]
    try:main(mode)
    except Exception:
        error=traceback.format_exc();(ROOT/(mode+'_error.txt')).write_text(error,encoding='utf-8');print(error,flush=True);raise
