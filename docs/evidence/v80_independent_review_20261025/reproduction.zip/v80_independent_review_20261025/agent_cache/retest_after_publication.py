"""Real native strategy result publication plus final signal-emission races."""
import pathlib, concurrent.futures, threading
P=pathlib.Path(__file__).resolve().parent/'retest_after.py'
setup=P.read_text(encoding='utf-8').split('reset();good=')[0]
exec(compile(setup,str(P),'exec'),globals())
reset();bot=m.CombinedStrategyV80();frames=bot._cached_fetch_data(msg)
real_run=bot._run_strategies;ready=threading.Event();release=threading.Event()
def timed_run(*a,**kw):
    result=real_run(*a,**kw)
    ready.set();assert release.wait(60)
    return result
bot._run_strategies=timed_run
with concurrent.futures.ThreadPoolExecutor(max_workers=1) as pool:
    fut=pool.submit(bot._cached_run_strategies,*frames,allow_unresolved_suba_volume=True)
    assert ready.wait(300),'native strategy computation did not finish'
    conflict();mode[0]='good';release.set()
    try:fut.result(timeout=60)
    except m.VerifiedDataRepairConflict as exc:note(case='native_strategy_inflight_conflict',blocked=True,error=str(exc),strategy_cache_entries=len(bot._request_strategy_cache))
    else:note(case='native_strategy_inflight_conflict',blocked=False,strategy_cache_entries=len(bot._request_strategy_cache))
bot._run_strategies=real_run
mode[0]='good';frames=bot._cached_fetch_data(msg)
real_compute=bot._compute_signal_data
def computed_then_conflict(*a,**kw):
    result=real_compute(*a,**kw)
    conflict()
    return result
bot._compute_signal_data=computed_then_conflict
text=capture(bot,bot._handle_signal,'signal_compute_return_conflict')
note(case='conflict_after_signal_compute_before_handler_emission',pending=m._v80_integrity_pending(),attachments=msg.attachments,normal_signal=bool(msg.attachments),failed='信号查询失败' in text or '信号计算/展示失败' in text,mentions_conflict='Known data integrity' in text or 'prefix factor conflicts' in text,boundary='Actual _compute_signal_data and signal handler; deterministic schedule injection immediately after computation, before normal output. Not proof of Poe concurrency model.')
(ROOT/'publication_results.json').write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf-8')
