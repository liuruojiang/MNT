"""Priority real signal-computation/emission race on 726e201."""
import pathlib
P=pathlib.Path(__file__).resolve().parent/'retest_after.py'
setup=P.read_text(encoding='utf-8').split('reset();good=')[0].replace('9af446711cff537b87cda11cc9c0a91192cf70fbeaed3867b3e2bc218bd25c7b','726e201c4ef7a8480296c9bc7813819d3a6e5e9e2ce3aaccca5f65232b23a44c').replace("ROOT=BASE/'after'","ROOT=BASE/'after_726e'")
exec(compile(setup,str(P),'exec'),globals())
reset();bot=m.CombinedStrategyV80();frames=bot._cached_fetch_data(msg)
real_compute=bot._compute_signal_data
def computed_then_conflict(*a,**kw):
    result=real_compute(*a,**kw)
    conflict()
    return result
bot._compute_signal_data=computed_then_conflict
try:
    text=capture(bot,bot._handle_signal,'signal_compute_return_conflict')
except m.VerifiedDataRepairConflict as exc:
    text=msg.buf.getvalue();(ROOT/'signal_compute_return_conflict.txt').write_text(text,encoding='utf-8')
    note(case='conflict_after_signal_compute_before_handler_emission',blocked=True,error=str(exc),pending=m._v80_integrity_pending(),attachments=msg.attachments,text_length=len(text),boundary='Actual native fetch, strategy, _compute_signal_data and handler; only scheduler injection immediately after successful computation')
else:
    note(case='conflict_after_signal_compute_before_handler_emission',blocked=False,pending=m._v80_integrity_pending(),attachments=msg.attachments)
# Validate guarded write and attachment independently after observed conflict.
guarded=m._V80VerifiedMessage(msg,0)
for action in ('write','attach_file'):
    try:
        if action=='write':guarded.write('stale normal signal')
        else:guarded.attach_file(name='blocked.xlsx',contents=b'not_sent')
    except m.VerifiedDataRepairConflict as exc:note(case='guarded_'+action,blocked=True,error=str(exc))
    else:note(case='guarded_'+action,blocked=False)
(ROOT/'publication_results.json').write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf-8')
