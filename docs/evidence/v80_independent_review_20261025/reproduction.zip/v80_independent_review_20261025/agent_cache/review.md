# V8.0 缓存与错误传播独立复核

冻结源码：`before/mnt_bot V 8.0 plus.py`，SHA256 `d4bcc51af3725686e19725dc253525fa8d483e0884cee9a033d423fd4d6438c9`。只读生产repo与冻结源码；未联网、未访问账号、未使用QVeris、未改策略参数或部署。

## 结论

V1.6 的跨请求 TTL 缓存/过期原始价格回退，不能原样套到 V8.0。V8.0 的 `run()`（13926–13928）每次清空 `_request_data_cache` 与 `_request_strategy_cache`；本次实测重新 `run()` 遇 Yahoo 普通网络错且 Stooq 不可用时中止，无附件，两缓存均为空。

但确认同一实例/同一进程的完整性撤销缺口：独立底层请求观察到 KMLM 确定性冲突后，现有缓存和并发在途请求没有任何失效/撤销门槛。后继普通网络错误可重新启用 Stooq。普通串行 `run()` 不会因旧实例缓存直接复活，但也不保留已观察冲突的来源资格限制。

### 1. 已填充 request 缓存后直接 handler 重入：可执行，P2（路径受限）

真实完整 `_cached_fetch_data` 和 `_cached_run_strategies` 计算，四输入截至 2026-10-23，shape 分别 `(2284,6)/(2921,5)/(4883,22)/(5991,19)`。之后 `fetch_yahoo('KMLM')` 以真实原始响应仅将 adjusted close 改为 raw close，触发真实 `VerifiedDataRepairConflict: KMLM earlier action/prefix factor conflicts on 2021-12-29`。紧接同实例 `_handle_signal()`：

- 新 HTTP 调用 0；两个缓存仍各 1 项。
- 正式信号 handler 输出正常仓位和信号，attach `signal_20261024.xlsx`。
- 输出不含原冲突。

源码：`_cached_fetch_data` 13713–13723、`_cached_run_strategies` 13725–13733；异常路径不清除已成功缓存，命中时不做完整性门槛。

边界：这是直接 handler 重入/同进程辅助调用路径，不等于用户重新发送命令时 `run()` 会复用此缓存；普通 `run()` 有明确清空保护。没有证据证明 Poe 不同用户查询复用同一实例，不据此提高到跨请求生产P1。

### 2. 原生 fetch 在途时观察冲突，仍发布 request 缓存：可执行，P2（并发/同进程）

`reproduce_inflight.py` 使用完整原生 `_fetch_data` 与真实归档响应，在 Yahoo QQQ 传输处暂停工作线程（KMLM 原生好数据已取完）。主线程对 KMLM 观察上述真实异常后释放工作线程。结果：原在途完整获取照常成功并写入 request cache；下一次 `_cached_fetch_data` 0次HTTP、原tuple同一对象返回。未替换 `_fetch_data` 或策略函数。

边界：人为安排线程调度；未实测 Poe 部署的线程/实例生命周期，也未跑真实在线竞态。该结果证明实现无撤销栅栏，不能独自证明线上必现。

### 3. 后继 Yahoo 网络错重新允许 Stooq：控制流已证实，P2（来源资格门槛）

当前一次 `fetch_yahoo` 观察 `VerifiedDataRepairConflict` 会立即 raise（3111–3112），同次不降级 Stooq，保护有效。随后另次 KMLM 请求若仅抛普通网络错误，循环仍进入 `_fetch_us_stooq` 并返回 `Stooq`，无此前确定性冲突记录；`_fetch_data` 13589–13591只提示Stooq复权未经独立核验，仍可继续进入正式历史/策略路径。

本次实测 Stooq HTTP CSV **使用真实 Yahoo raw open/close 序列化为 Stooq schema**，实际经过 `_fetch_us_stooq`、`fetch_yahoo`，返回1480行。它只证明控制流，不是独立Stooq行情正确性或完整正式信号验收。没有真实捕获，未声称已从真实Stooq在线响应产生正常策略信号。

## 本次确认的保护

- fresh `_handle_signal` 遇冲突输出“信号查询失败”和原异常，无附件。
- `_handle_params` 可输出参数页，但标明“当前状态读取不完整”及原冲突，无正常信号附件；参数页降级本身不算正常交易信号复活。
- 普通重新 `run()` 清空两个实例缓存；Yahoo/Stooq全离线时阻断，不像V1.6回退过期原始价格。
- `VerifiedDataRepairConflict` 继承RuntimeError，不在 `_DATA_FETCH_ERRORS` 中，核心源切换不会同次把其当暂态错误吞掉。

## 证据与复现

命令（全部 `python -B`，无pytest缓存）：

1. `python -B work/v80_independent_review_20261025/agent_cache/reproduce_cache.py`
2. `python -B work/v80_independent_review_20261025/agent_cache/reproduce_inflight.py`

结果：`results.json`、`inflight_results.json`，完整日志 `console.txt`、`inflight_console.txt`，正式handler文本 `same_instance_after_conflict.txt` / `run_after_conflict_then_network.txt` / `fresh_handler_conflict.txt` / `params_conflict.txt`。

数据：`work/source_validation/tiingo_authenticated/yahoo_current`（Yahoo原始响应），`work/source_validation/sina_shadow`，`work/conflict_investigation/independent`（CSI、Sohu），`work/v80_full_replay/independent/cni_cyb_overlap.json`。沿用已有独立CNI缺口证据补齐Sohu的2018-12-14创业板成交额；未改价格或参数。正式捕获 `work/independent_candidate_review/validated_r2/formal_run.pkl` 已不存在，本次重新从真实归档跑完整原生路径。未计算/声称新的绩效比较。

未验证：真实在线Stooq调整口径；Poe服务器对象共享与并发模型；完整线上环境；实时handler已填充独立true/true缓存后的正常展示；冻结源码修复后复测（尚待主Agent给出候选）。
