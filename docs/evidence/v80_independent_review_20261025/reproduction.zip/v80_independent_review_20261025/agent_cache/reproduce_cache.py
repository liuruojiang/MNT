"""Independent offline review. All HTTP denied except recorded real payloads.

Injected conditions: KMLM adjusted=raw conflict, network failure and Stooq
transport supplied as real Yahoo close/open serialization (control-flow ONLY;
not claimed as independently verified real Stooq market data).
"""
import copy, hashlib, importlib.util, io, json, os, pathlib, sys, types
from datetime import datetime, timezone
from urllib.parse import urlparse, parse_qs, urlencode
import pandas as pd
import requests

ROOT=pathlib.Path(__file__).resolve().parent
WORK=ROOT.parents[1]
SOURCE=ROOT.parent/'before/mnt_bot V 8.0 plus.py'
assert hashlib.sha256(SOURCE.read_bytes()).hexdigest()=='d4bcc51af3725686e19725dc253525fa8d483e0884cee9a033d423fd4d6438c9'
os.chdir(ROOT)
spec=importlib.util.spec_from_file_location('v80_independent_cache',SOURCE)
m=importlib.util.module_from_spec(spec);sys.modules[spec.name]=m;spec.loader.exec_module(m)
STAMP=datetime(2026,10,24,0,15,tzinfo=timezone.utc)
class FrozenDatetime(datetime):
    @classmethod
    def now(cls,tz=None):return STAMP.astimezone(tz) if tz else STAMP.replace(tzinfo=None)
m.datetime=FrozenDatetime
m.time=types.SimpleNamespace(**{k:getattr(m.time,k) for k in dir(m.time) if not k.startswith('__')})
m.time.sleep=lambda *_:None
def read(p):
    if not p.exists():raise requests.ConnectionError('No frozen payload '+str(p))
    return json.loads(p.read_text(encoding='utf-8'))
class Response:
    status_code=200
    def __init__(self,data=None,text=None):self.data=data;self.text=text if text is not None else json.dumps(data);self.content=self.text.encode()
    def json(self):return copy.deepcopy(self.data)
    def raise_for_status(self):pass

sohu=read(WORK/'conflict_investigation/independent/sohu_cyb.json')
cni=read(WORK/'v80_full_replay/independent/cni_cyb_overlap.json')['data']
f=pd.DataFrame(cni['data'],columns=cni['item'])
f.index=pd.to_datetime(f.timestamp,unit='ms',utc=True).dt.tz_convert('Asia/Shanghai').dt.tz_localize(None).dt.normalize()
t=f.loc['2018-12-14']
sohu[0]['hq'].append(['2018-12-14',str(t.open),str(t.close),str(t.chg),str(t.percent*100)+'%',str(t.low),str(t.high),str(t.volume/100),str(t.amount/10000),'-'])
sohu[0]['hq'].sort(key=lambda r:r[0],reverse=True)
mode=['good'];calls=[];out=[]
def get(url,*a,**kw):
    if kw.get('params'):url+=('&' if '?' in url else '?')+urlencode(kw['params'])
    q=parse_qs(urlparse(url).query);path=urlparse(url).path
    if '/finance/chart/' in path:
        symbol=path.rsplit('/',1)[1];calls.append((symbol,mode[0]))
        if symbol=='KMLM' and mode[0] in ('offline','offline_stooq'):raise requests.ConnectionError('injected offline after observed conflict')
        p=WORK/'source_validation/tiingo_authenticated/yahoo_current'/f'{symbol}.json'
        if not p.exists():p=WORK/'conflict_investigation/independent'/f'{symbol}.json'
        if not p.exists():raise requests.ConnectionError('No frozen Yahoo '+symbol)
        v=read(p);r=v['chart']['result'][0]
        if symbol=='KMLM' and mode[0]=='conflict':r['indicators']['adjclose'][0]['adjclose']=r['indicators']['quote'][0]['close'].copy()
        lo=int(q.get('period1',['0'])[0]);hi=min(int(q.get('period2',[str(int(STAMP.timestamp()))])[0]),int(STAMP.timestamp()))
        ix=[i for i,t in enumerate(r['timestamp']) if lo<=t<hi]
        r['timestamp']=[r['timestamp'][i] for i in ix]
        for b in r['indicators']['quote']+r['indicators']['adjclose']:
            for k,values in b.items():b[k]=[values[i] for i in ix]
        return Response(v)
    if 'stooq.com/q/d/l/' in url:
        calls.append(('STOOQ',mode[0]))
        if mode[0]!='offline_stooq':raise requests.ConnectionError('no Stooq archive; offline transport')
        v=read(WORK/'source_validation/tiingo_authenticated/yahoo_current/KMLM.json')['chart']['result'][0]
        dates=pd.to_datetime(v['timestamp'],unit='s',utc=True).tz_localize(None).normalize()
        z=pd.DataFrame({'Date':dates,'Open':v['indicators']['quote'][0]['open'],'Close':v['indicators']['quote'][0]['close']}).dropna()
        return Response(text=z.to_csv(index=False))
    if 'CN_MarketData.getKLineData' in path:return Response(read(WORK/'source_validation/sina_shadow'/f"{q['symbol'][0]}.json"))
    if 'csindex-home/perf/index-perf' in path:return Response(read(WORK/'conflict_investigation/independent'/f"csi_{q['indexCode'][0]}_full.json"))
    if 'csindex.com.cn/indices/index-detail/' in url:return Response({})
    if 'q.stock.sohu.com/hisHq' in url and q.get('code',[''])[0]=='zs_399006':return Response(sohu)
    raise requests.ConnectionError('HTTP denied; missing archive '+url.split('?')[0])
m._session.get=get
requests.sessions.Session.get=lambda self,url,*a,**kw:get(url,*a,**kw)
requests.get=get
class Message:
    def __init__(self):self.buf=io.StringIO();self.attachments=[]
    def __enter__(self):return self
    def __exit__(self,*a):pass
    def write(self,x):self.buf.write(str(x))
    def attach_file(self,**kw):self.attachments.append(kw['name'])
msg=Message();m._sm=lambda:msg
def note(**kw):out.append(kw);print(json.dumps(kw,ensure_ascii=False),flush=True)
def capture(bot,handler,name):
    msg.buf=io.StringIO();msg.attachments=[];handler()
    text=msg.buf.getvalue();(ROOT/(name+'.txt')).write_text(text,encoding='utf-8')
    return text
bot=m.CombinedStrategyV80()
frames=bot._cached_fetch_data(msg)
note(case='baseline_real_formal_fetch',shapes=[list(x.shape) for x in frames],ends=[str(x.index[-1]) for x in frames],data_cache_keys=list(bot._request_data_cache))
strategies=bot._cached_run_strategies(*frames,allow_unresolved_suba_volume=True)
note(case='baseline_real_formal_strategies',strategy_cache_entries=len(bot._request_strategy_cache),ends=[str(x.index[-1]) if x is not None else None for x in strategies])
mode[0]='conflict'
try:m.fetch_yahoo('KMLM')
except m.VerifiedDataRepairConflict as exc:error=str(exc)
else:raise AssertionError('real loader failed to raise conflict')
before=len(calls);text=capture(bot,bot._handle_signal,'same_instance_after_conflict')
note(case='same_instance_cached_handler_after_conflict',conflict=error,new_http_calls=len(calls)-before,normal_signal='当前→' in text or '当前持仓' in text or bool(msg.attachments),attachments=msg.attachments,data_cache_entries=len(bot._request_data_cache),strategy_cache_entries=len(bot._request_strategy_cache),contains_conflict=error in text)
mode[0]='offline'
m.poe.query=types.SimpleNamespace(text='信号',attachments=[])
text=capture(bot,bot.run,'run_after_conflict_then_network')
note(case='run_clears_caches_no_raw_resurrection',failed='信号查询失败' in text or '查询入口失败' in text,data_cache_entries=len(bot._request_data_cache),strategy_cache_entries=len(bot._request_strategy_cache),attachments=msg.attachments)
mode[0]='conflict';text=capture(bot,bot._handle_signal,'fresh_handler_conflict')
note(case='fresh_signal_handler_conflict',failed='信号查询失败' in text,mentions_conflict=error in text,attachments=msg.attachments)
text=capture(bot,bot._handle_params,'params_conflict')
note(case='params_handler_conflict',incomplete='当前状态读取不完整' in text,mentions_conflict=error in text,attachments=msg.attachments)
mode[0]='offline_stooq';calls.clear()
df,source=m.fetch_yahoo('KMLM')
note(case='subsequent_network_failure_reaches_stooq',source=source,rows=0 if df is None else len(df),calls=calls.copy(),boundary='Stooq CSV constructed from recorded Yahoo raw OHLC: actual fetch_yahoo/_fetch_us_stooq; control-flow validation only')
(ROOT/'results.json').write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf-8')
