# 9af4467 候选独立复测

对象：`after/mnt_bot V 8.0 plus.py`，SHA256 `9af446711cff537b87cda11cc9c0a91192cf70fbeaed3867b3e2bc218bd25c7b`。

`python -B work/v80_independent_review_20261025/agent_cache/retest_after.py` 已运行完成，12个结果项详见 `results.json`。未联网、未修改候选或生产repo；沿用初审真实响应离线transport，假设/反例注入仅为明确指定的冲突、过期、截短、上游已修正与调度条件。

已证实改好：

- 同实例旧request cache后正式信号handler：阻断、无附件、两cache均0。
- 已知冲突后Yahoo网络错：阻断，Stooq传输调用0。
- 原生完整_fetch_data在途竞争：观察冲突后旧在途获取阻断，数据cache0。
- 正常run清缓存边界保留：冲突后run网络错无附件且两cache0。
- 完整Yahoo修复数据1480行恢复；人工构造的上游已修正完整Yahoo数据1480行亦恢复，source明确upstream-complete。
- stale数据、此前成功完整coverage存在时的截短数据不能恢复；完整有效重取仍能恢复。
- 即使全新Yahoo恢复，旧generation标签输入仍在策略计算前被拒绝。

尚有可执行问题：首次恢复没有先前coverage时，可用显式后移requested start截短历史并清除故障。新模块首先实际fetch_yahoo触发KMLM冲突，不先取成功好数据，然后 `fetch_yahoo('KMLM', start_date='2021-01-04')`，返回1459行、source=Yahoo+verified-repair、pending=False。完整应1480行。源码 `_v80_accept_price_source` 的 expected从valid[0]起算，`coverage`默认为空；`fetch_yahoo` 的requested start保护也会随显式参数后移。因此首次故障的恢复未强制覆盖KMLM verified inception（2020-12-02）。这未证明普通正式_fetch_data会主动这样请求，但未满足“截短恢复不能清故障”的绝对约束，建议按P2处理。

`python -B work/v80_independent_review_20261025/agent_cache/retest_after_publication.py` 已完成，结果在 `publication_results.json`：

- 实际原生_run_strategies完整计算后暂停返回，再观察KMLM冲突后释放，cache包装器阻断且strategy cache0；修复有效。
- 另一个最终输出竞态仍成立：完整native fetch/strategy/_compute_signal_data完成后、正式_handle_signal写正常信号前，实际fetch_yahoo观察KMLM冲突再返回原计算结果。handler仍attach `signal_20261024.xlsx`，pending=True，既未报失败也未提示冲突。证据 `signal_compute_return_conflict.txt`。本测试仅在真实_compute_signal_data返回处插入确定性调度，不替换策略数学；未证明Poe真实部署会并发共享对象。按P2并发边界问题记录，候选仍不宜宣称全部门槛通过。
