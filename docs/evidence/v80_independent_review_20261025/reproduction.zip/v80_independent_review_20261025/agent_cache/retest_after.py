"""Independent candidate retest, actual loaders and handlers, offline only."""
import pathlib, gzip, pickle, threading, concurrent.futures
BASE=pathlib.Path(__file__).resolve().parent
prefix=(BASE/'reproduce_cache.py').read_text(encoding='utf-8').split('bot=m.CombinedStrategyV80()\n')[0]
prefix=prefix.replace("ROOT.parent/'before/mnt_bot V 8.0 plus.py'","ROOT.parent/'after/mnt_bot V 8.0 plus.py'").replace('d4bcc51af3725686e19725dc253525fa8d483e0884cee9a033d423fd4d6438c9','9af446711cff537b87cda11cc9c0a91192cf70fbeaed3867b3e2bc218bd25c7b')
exec(compile(prefix,str(BASE/'reproduce_cache.py'),'exec'),globals())
ROOT=BASE/'after';ROOT.mkdir(exist_ok=True)
native=pickle.load(gzip.open(BASE.parent/'baseline/native_inputs.pkl.gz','rb'))
original_get=get
def get2(url,*a,**kw):
    if '/finance/chart/KMLM?' in url and mode[0] in ('stale','upstream_complete'):
        saved=mode[0];mode[0]='good'
        try:resp=original_get(url,*a,**kw)
        finally:mode[0]=saved
        v=resp.data;r=v['chart']['result'][0]
        if saved=='stale':
            ix=list(range(len(r['timestamp'])-1));r['timestamp']=[r['timestamp'][i] for i in ix]
            for b in r['indicators']['quote']+r['indicators']['adjclose']:
                for k,vals in b.items():b[k]=[vals[i] for i in ix]
        else:
            q=r['indicators']['quote'][0];adj=r['indicators']['adjclose'][0]['adjclose']
            repaired,note=m._repair_verified_kmlm_distribution('KMLM',r['timestamp'],q,adj)
            r['indicators']['adjclose'][0]['adjclose']=repaired
        return Response(v)
    return original_get(url,*a,**kw)
m._session.get=get2
requests.sessions.Session.get=lambda self,url,*a,**kw:get2(url,*a,**kw)
requests.get=get2
def reset():
    m._V80_INTEGRITY_GENERATION=0;m._V80_INTEGRITY_CONFLICTS.clear();m._V80_INTEGRITY_COVERAGE.clear();mode[0]='good';calls.clear()
def conflict():
    mode[0]='conflict'
    try:m.fetch_yahoo('KMLM')
    except m.VerifiedDataRepairConflict as exc:return str(exc)
    raise AssertionError('expected conflict')
def tryfetch(name,start='2003-01-01'):
    try:
        f,s=m.fetch_yahoo('KMLM',start_date=start)
        note(case=name,status='returned',rows=0 if f is None else len(f),source=s,pending=m._v80_integrity_pending(),generation=m._v80_integrity_generation())
        return f,s
    except m.VerifiedDataRepairConflict as exc:
        note(case=name,status='blocked',error=str(exc),pending=m._v80_integrity_pending(),generation=m._v80_integrity_generation())
        return None,None

reset();good=m.fetch_yahoo('KMLM');conflict();mode[0]='offline_stooq';calls.clear();tryfetch('known_conflict_then_network_stooq');note(case='known_conflict_no_stooq_transport',stooq_calls=sum(s=='STOOQ' for s,md in calls))
mode[0]='good';tryfetch('complete_yahoo_recovery')
conflict();mode[0]='upstream_complete';tryfetch('complete_upstream_corrected_recovery')
conflict();mode[0]='stale';tryfetch('stale_recovery_must_not_clear')
mode[0]='good';tryfetch('truncated_recovery_with_prior_coverage','2021-01-04')
mode[0]='good';tryfetch('complete_after_rejected_recovery')
# Important fresh-process boundary: there is no successful coverage observation.
reset();conflict();mode[0]='good';tryfetch('truncated_recovery_without_prior_coverage','2021-01-04')

# Old actual baseline inputs/cache: formal handler must reject after conflict.
reset();bot=m.CombinedStrategyV80();frames=native['inputs'];bot._us_open=native['us_open']
for f in frames:f.attrs['verified_integrity_generation']=0
bot._request_integrity_generation=0;bot._request_data_cache={(False,False,False):frames};bot._request_strategy_cache={'old_success':'not_executed'}
conflict();mode[0]='offline_stooq'
text=capture(bot,bot._handle_signal,'same_instance_after_conflict')
note(case='same_instance_formal_handler_conflict',failed='信号查询失败' in text,attachments=msg.attachments,data_cache_entries=len(bot._request_data_cache),strategy_cache_entries=len(bot._request_strategy_cache))
m.poe.query=types.SimpleNamespace(text='信号',attachments=[])
text=capture(bot,bot.run,'run_after_conflict_network')
note(case='run_after_conflict_network',failed='信号查询失败' in text or '查询入口失败' in text,attachments=msg.attachments,data_cache_entries=len(bot._request_data_cache),strategy_cache_entries=len(bot._request_strategy_cache))
mode[0]='good';m.fetch_yahoo('KMLM')
try:bot._cached_run_strategies(*frames,allow_unresolved_suba_volume=True)
except m.VerifiedDataRepairConflict as exc:note(case='old_tagged_inputs_after_recovery',blocked=True,error=str(exc))
else:note(case='old_tagged_inputs_after_recovery',blocked=False)

# Native full acquisition racing actual conflict; no fake price frames.
reset();ready=threading.Event();release=threading.Event()
def timed_get(url,*a,**kw):
    if '/finance/chart/QQQ?' in url and threading.current_thread().name.startswith('native_fetch'):
        ready.set();assert release.wait(60)
    return get2(url,*a,**kw)
m._session.get=timed_get
requests.sessions.Session.get=lambda self,url,*a,**kw:timed_get(url,*a,**kw)
requests.get=timed_get
bot=m.CombinedStrategyV80()
with concurrent.futures.ThreadPoolExecutor(max_workers=1,thread_name_prefix='native_fetch') as pool:
    future=pool.submit(bot._cached_fetch_data,msg)
    assert ready.wait(60);error=conflict();mode[0]='good';release.set()
    try:future.result(timeout=60)
    except m.VerifiedDataRepairConflict as exc:note(case='native_fetch_inflight_conflict',blocked=True,error=str(exc),data_cache_entries=len(bot._request_data_cache))
    else:note(case='native_fetch_inflight_conflict',blocked=False,data_cache_entries=len(bot._request_data_cache))

(ROOT/'results.json').write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf-8')
