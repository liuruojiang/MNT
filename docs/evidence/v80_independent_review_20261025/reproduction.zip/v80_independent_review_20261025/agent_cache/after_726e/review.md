# 726e201 候选独立复测

冻结对象：`after/mnt_bot V 8.0 plus.py`，SHA256 `726e201c4ef7a8480296c9bc7813819d3a6e5e9e2ce3aaccca5f65232b23a44c`。本轮15个结果项均达到预期；先前9af候选发现的首次无coverage截短恢复、最终信号输出竞态均已关闭。本报告只确认缓存、错误传播、恢复和发布门槛；未替代主Agent的全量数学/绩效parity。

实际执行：

1. `python -B work/v80_independent_review_20261025/agent_cache/retest_726e.py`
2. `python -B work/v80_independent_review_20261025/agent_cache/retest_publication_726e.py`

第一组12项在 `results.json`：

- 已知冲突后Yahoo网络错阻断，Stooq调用0。
- 完整原始Yahoo分红修复数据1480行可恢复；人工构造的完整上游已修正Yahoo数据1480行可恢复。
- 过期数据不可恢复。
- 有既往coverage、首次无coverage两种显式后移start截短情况均不能清除故障。
- 拒绝截短/过期之后，重新完整有效Yahoo可恢复。
- 同实例旧cache后正式信号handler阻断、两cache0、附件0。
- 冲突后重新run遇网络错阻断、两cache0、附件0；保持每次run清空实例缓存的真实保护。
- 完整恢复后旧generation标签输入仍被策略入口拒绝。
- 真实归档+完整原生_fetch_data在途线程观察到冲突后被阻断，request cache0。

第二组3项在 `publication_results.json`：

- **真实完整native fetch、策略计算、_compute_signal_data和正式_handle_signal**：计算成功后、handler写正常信号前插入实际KMLM冲突；handler在正常payload首次write前阻断，附件0，文本仅26字符进度消息。未用替身策略数学或假行情frame。
- 已观察冲突后的_V80VerifiedMessage.write阻断。
- 已观察冲突后的_V80VerifiedMessage.attach_file阻断。

9af已执行且通过的实际原生_run_strategies在途结果发布测试，证据保留在`../after/publication_results.json`；726e的本轮实际策略计算也经过原生cache发布，但没有重复完整策略在途冲突测试。仅新增输出包装器和恢复完整覆盖条件，没有据此声称重跑全部独立策略数学。原始before及9af证据全部保留。

边界：全程只读候选及生产repo，HTTP仅本地真实归档；KMLM异常、上游已修正、过期和截短均为明确的反例变换。原生线程测试人为安排调度，未验证Poe真实部署的实例共享/并发模型；本轮Stooq因完整性门槛在传输前阻断，不声称验证其真实行情复权口径。未联网、未访问账号、未用QVeris、未改参数、未改生产、未部署Poe。

本轮日志：`../726e_console.txt`、`../726e_publication_console.txt`。正式handler输出：`same_instance_after_conflict.txt`、`run_after_conflict_network.txt`、`signal_compute_return_conflict.txt`。
