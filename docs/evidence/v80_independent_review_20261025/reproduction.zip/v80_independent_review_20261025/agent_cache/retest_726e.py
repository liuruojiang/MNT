"""Keep prior evidence, rerun identical acquisition/cache suite on 726e201."""
from pathlib import Path
P=Path(__file__).resolve().parent/'retest_after.py'
code=P.read_text(encoding='utf-8').replace('9af446711cff537b87cda11cc9c0a91192cf70fbeaed3867b3e2bc218bd25c7b','726e201c4ef7a8480296c9bc7813819d3a6e5e9e2ce3aaccca5f65232b23a44c').replace("ROOT=BASE/'after'","ROOT=BASE/'after_726e'")
exec(compile(code,str(P),'exec'),globals())
