"""Native acquisition race: only transport timing is injected, no fake frames."""
import pathlib, threading, concurrent.futures, json
P=pathlib.Path(__file__).resolve().parent/'reproduce_cache.py'
# Reuse reviewed offline real-response transport setup, without executing the
# expensive strategy/handler cases for a second unchanged baseline.
prefix=P.read_text(encoding='utf-8').split('bot=m.CombinedStrategyV80()\n')[0]
exec(compile(prefix,str(P),'exec'),globals())
original_get=get
ready=threading.Event();release=threading.Event()
def timed_get(url,*a,**kw):
    if '/finance/chart/QQQ?' in url and threading.current_thread().name.startswith('native_fetch'):
        ready.set()
        assert release.wait(60),'coordinator did not release frozen transport'
    return original_get(url,*a,**kw)
m._session.get=timed_get
requests.sessions.Session.get=lambda self,url,*a,**kw:timed_get(url,*a,**kw)
requests.get=timed_get
bot=m.CombinedStrategyV80()
with concurrent.futures.ThreadPoolExecutor(max_workers=1,thread_name_prefix='native_fetch') as pool:
    future=pool.submit(bot._cached_fetch_data,msg)
    assert ready.wait(60),'real acquisition did not reach QQQ after KMLM'
    assert any(s=='KMLM' and md=='good' for s,md in calls)
    mode[0]='conflict'
    try:m.fetch_yahoo('KMLM')
    except m.VerifiedDataRepairConflict as exc:error=str(exc)
    else:raise AssertionError('expected real KMLM conflict')
    mode[0]='good';release.set()
    frames=future.result(timeout=60)
before=len(calls);again=bot._cached_fetch_data(msg)
result={'case':'native_fetch_inflight_conflict_publishes_request_cache','error':error,'shapes':[list(x.shape) for x in frames],'ends':[str(x.index[-1]) for x in frames],'cache_entries':len(bot._request_data_cache),'second_fetch_http_calls':len(calls)-before,'same_tuple':again is frames,'boundary':'Full native _fetch_data + real archived responses; explicit thread/transport timing. This is same-instance/in-process concurrency, not proof Poe shares instances between user queries.'}
(ROOT/'inflight_results.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(result,ensure_ascii=False),flush=True)
