import gzip
import hashlib
import json
import re
from pathlib import Path
import pickle

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parent
NAME = 'mnt_bot V 8.0 plus.py'
SHA = '726e201c4ef7a8480296c9bc7813819d3a6e5e9e2ce3aaccca5f65232b23a44c'


def main():
    assert hashlib.sha256((ROOT / 'after' / NAME).read_bytes()).hexdigest() == SHA
    assert (ROOT / 'after/source_sha256.txt').read_text(encoding='ascii') == SHA
    assert (ROOT / 'baseline/source_sha256.txt').read_text(encoding='ascii') == 'd4bcc51af3725686e19725dc253525fa8d483e0884cee9a033d423fd4d6438c9'
    checks = {}
    for filename in ['all_daily_returns.csv','all_nav.csv','Sub-A_daily.csv','Sub-A-DK_daily.csv','B7.8_daily.csv','B7.9_daily.csv']:
        left = pd.read_csv(ROOT/'baseline'/filename, index_col=0, parse_dates=True)
        right = pd.read_csv(ROOT/'after'/filename, index_col=0, parse_dates=True)
        pd.testing.assert_frame_equal(left, right, check_exact=False, atol=1e-12, rtol=1e-12)
        cols = left.select_dtypes('number').columns
        delta = float((left[cols]-right[cols]).abs().max().max())
        checks[filename] = {'rows':len(left),'columns':len(left.columns),'max_abs_numeric_difference':delta,'within_atol_rtol_1e12':True,'non_numeric_exact_equal':left.drop(columns=cols).equals(right.drop(columns=cols))}
    assert (ROOT/'baseline/正式信号查询.txt').read_text(encoding='utf-8-sig') == (ROOT/'after/正式信号查询.txt').read_text(encoding='utf-8-sig')
    checks['正式信号查询.txt'] = {'exact_equal':True}
    before = json.loads((ROOT/'baseline/run_summary.json').read_text(encoding='utf-8'))
    after = json.loads((ROOT/'after/run_summary.json').read_text(encoding='utf-8'))
    def compare(left, right, key=''):
        if key == 'run_id': return
        if isinstance(left,dict):
            assert left.keys()==right.keys(),key
            for name in left: compare(left[name],right[name],name)
        elif isinstance(left,list):
            assert len(left)==len(right),key
            for a,b in zip(left,right): compare(a,b,key)
        elif isinstance(left,(int,float)) and not isinstance(left,bool):
            assert np.isclose(left,right,atol=1e-12,rtol=1e-12,equal_nan=True),key
        else: assert left==right,key
    for key in ['official_metrics','official_standard_windows','report_context','replay_flags']:
        compare(before[key],after[key],key)
    left=(ROOT/'baseline/正式绩效查询.txt').read_text(encoding='utf-8-sig')
    right=(ROOT/'after/正式绩效查询.txt').read_text(encoding='utf-8-sig')
    # The native report intentionally generates a new ID and attachment name.
    left=left.replace(before['report_context']['run_id'],'<REPORT_ID>')
    right=right.replace(after['report_context']['run_id'],'<REPORT_ID>')
    assert left==right
    checks['正式绩效查询.txt']={'exact_equal_after_report_id_normalization':True,'normalization':'run_id and its attachment filename only'}
    with gzip.open(ROOT/'baseline/native_inputs.pkl.gz','rb') as f: left=pickle.load(f)
    with gzip.open(ROOT/'after/native_inputs.pkl.gz','rb') as f: right=pickle.load(f)
    input_orders=[]
    for index,(a,b) in enumerate(zip(left['inputs'], right['inputs'])):
        assert set(a.columns)==set(b.columns)
        pd.testing.assert_frame_equal(a.sort_index(axis=1),b.sort_index(axis=1),check_exact=True)
        if not a.columns.equals(b.columns): input_orders.append({'input':index,'before':list(a.columns),'after':list(b.columns)})
    assert set(left['us_open'])==set(right['us_open'])
    for symbol in left['us_open']:
        pd.testing.assert_series_equal(left['us_open'][symbol],right['us_open'][symbol],check_exact=True)
    daily = pd.read_csv(ROOT/'after/all_daily_returns.csv',index_col=0,parse_dates=True)
    combined = daily['Combined'].dropna()
    scope = json.loads((ROOT/'source_scope.json').read_text(encoding='utf-8'))
    result = {'final_sha256':SHA,'baseline_commit':scope['before_commit'],
              'cutoff':'2026-10-23','replay_clock':'2026-10-24 08:15 Asia/Shanghai',
              'scope':'Original full V8 performance and signal handlers; original raw Yahoo/Sohu responses; no synthetic strategy return streams',
              'parity':checks,'original_global_assignments_unchanged':scope['original_global_assignments_unchanged'],
              'actual_us_open_equal_by_symbol':True,'all_four_inputs_equal_by_symbol':True,
              'input_column_order_differences':input_orders,
              'numeric_parity_tolerance':{'atol':1e-12,'rtol':1e-12},
              'standard_windows':after['official_standard_windows'],
              'combined_start':str(combined.index.min().date()),'combined_end':str(combined.index.max().date()),
              'combined_rows':len(combined),'combined_terminal_nav':float((1+combined).prod()),
              'strict_native_baseline_parity':after['formal_baseline_parity'],
              'paper_boundary':'Original costs, financing, open execution, overlays, sleeve capital drift and pre-2024 Sub-C BTC proxy retained; not account/Poe deployment acceptance'}
    (ROOT/'native_parity.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps({k:v for k,v in result.items() if k not in ['standard_windows']},ensure_ascii=False,indent=2))


if __name__=='__main__': main()
