import copy, hashlib, importlib.util, json, pathlib, sys
from unittest.mock import patch
import numpy as np
import pandas as pd

BASE = pathlib.Path(__file__).resolve().parents[2]
OUT = pathlib.Path(__file__).resolve().parent
REPO = pathlib.Path('D:/动量策略/A股美股动量组合策略')
CODE = pathlib.Path(sys.argv[1]) if len(sys.argv)>1 else OUT.parent/'before/mnt_bot V 8.0 plus.py'
FIX = REPO/'tests/fixtures/v80_verified_data_20261025/yahoo_kmlm.json'
def forbidden(*a, **kw): raise AssertionError('Independent audit forbids network and account access')
import requests
with patch.object(requests.sessions.Session, 'request', side_effect=forbidden):
    spec=importlib.util.spec_from_file_location('independent_ca',CODE)
    m=importlib.util.module_from_spec(spec); sys.modules[spec.name]=m; spec.loader.exec_module(m)

payload=json.loads(FIX.read_text(encoding='utf-8')); original=payload['chart']['result'][0]
dates=pd.to_datetime(original['timestamp'],unit='s',utc=True).tz_localize(None).normalize()
ex=pd.Timestamp('2022-12-28'); ip=dates.get_loc(pd.Timestamp('2022-12-27')); ie=dates.get_loc(ex)
raw=np.array(original['indicators']['quote'][0]['close'],float)
adj=np.array(original['indicators']['adjclose'][0]['adjclose'],float)
observed=(adj[ip]/raw[ip])/(adj[ie]/raw[ie]); scale=(1-4.0377/raw[ip])/observed
expected=adj.copy(); expected[dates<ex]*=scale
def response(data):
    class R:
        status_code=200
        def json(self):return data
    return R()
def public(data):
    calls=[]
    def fallback(*a,**kw):
        calls.append('Stooq')
        result=control.copy(); result.attrs={}
        return result
    with patch.object(m.requests.sessions.Session,'request',side_effect=forbidden),patch.object(m._session,'get',return_value=response(data)),patch.object(m,'_fetch_us_stooq',side_effect=fallback),patch.object(m,'_repair_us_yahoo_internal_gaps_with_nasdaq',side_effect=lambda ticker,df:(df,0,0)),patch.object(m.time,'sleep',return_value=None):
        try:
            frame,source=m.fetch_yahoo('KMLM')
            result={'status':'returned','source':source,'fallback_calls':calls,'rows':len(frame) if frame is not None else None}
            if frame is not None:
                expected_frame=pd.Series(expected,index=dates)
                result['missing_dates_vs_verified_control']=[d.date().isoformat() for d in dates.difference(frame.index)]
                result['max_relative_error_vs_verified_control']=float(np.max(np.abs(frame.close.to_numpy()/expected_frame.reindex(frame.index).to_numpy()-1)))
                for day in ['2022-12-27','2022-12-28','2022-12-29','2023-06-01','2023-06-02']:
                    if pd.Timestamp(day) in frame.index: result[day]=float(frame.loc[day,'close'])
            return result
        except Exception as e:return {'status':'raised','error_type':type(e).__name__,'message':str(e),'fallback_calls':calls}

with patch.object(m._session,'get',return_value=response(payload)),patch.object(m.requests.sessions.Session,'request',side_effect=forbidden):
    control=m._fetch_us_yahoo('KMLM')
np.testing.assert_allclose(control.close,expected,rtol=1e-13,atol=1e-13)
results={}
def case(name,mutator):
    p=copy.deepcopy(payload);mutator(p['chart']['result'][0]);results[name]=public(p)
def setadj(y,a):y['indicators']['adjclose'][0]['adjclose']=list(a)
case('normal_untouched_fixture',lambda y:None)
case('already_correct_prefix_idempotent',lambda y:setadj(y,expected))
for full in [4.0377,4.038]:
    a=adj.copy();a[dates<ex]*=(1-full/raw[ip])/observed
    case('upstream_full_'+str(full),lambda y,a=a:setadj(y,a))
    case('upstream_full_float32_'+str(full),lambda y,a=a:setadj(y,a.astype(np.float32).astype(float)))
for seam in ['2022-12-23','2022-12-28','2023-06-01','2024-12-16','2024-12-17','2025-12-22']:
    a=adj.copy();a[dates<=pd.Timestamp(seam)]*=scale
    case('partial_scaling_through_'+seam,lambda y,a=a:setadj(y,a))
case('missing_adjclose_block',lambda y:y['indicators'].pop('adjclose'))
case('missing_adjclose_array',lambda y:y['indicators']['adjclose'][0].pop('adjclose'))
case('short_adjclose_array',lambda y:y['indicators']['adjclose'][0]['adjclose'].pop())
case('suffix_adjclose_none',lambda y:y['indicators']['adjclose'][0]['adjclose'].__setitem__(-1,None))
case('adjclose_array_wrong_type',lambda y:y['indicators']['adjclose'][0].__setitem__('adjclose',42))
case('adjclose_block_wrong_type',lambda y:y['indicators'].__setitem__('adjclose',[42]))
case('quote_array_wrong_type',lambda y:y['indicators'].__setitem__('quote',[42]))
case('timestamp_empty',lambda y:y.__setitem__('timestamp',[]))
case('timestamp_array_wrong_type',lambda y:y.__setitem__('timestamp',42))
case('indicators_wrong_type',lambda y:y.__setitem__('indicators',42))
case('suffix_close_none',lambda y:y['indicators']['quote'][0]['close'].__setitem__(-1,None))
for label,val in [('invalid_string','not-a-timestamp'),('none',None),('nan',float('nan')),('overflow',10**30),('dict',{'timestamp':1})]:
    case('timestamp_'+label,lambda y,val=val:y['timestamp'].__setitem__(ie,val))
case('timestamp_duplicate',lambda y:y['timestamp'].__setitem__(ie,y['timestamp'][ip]))

independent={}
tp=BASE/'source_validation/tiingo_authenticated/KMLM_prices.json'
yp=BASE/'conflict_investigation/independent/yahoo_kmlm_all_actions.json'
for name,path in [('tiingo',tp),('yahoo_actions',yp)]:
    v=json.loads(path.read_text(encoding='utf-8'))
    independent[name]={'path':str(path),'sha256':hashlib.sha256(path.read_bytes()).hexdigest()}
    if name=='tiingo': independent[name]['actions']=[{'date':r['date'],'divCash':r['divCash'],'splitFactor':r['splitFactor']} for r in v if r['divCash']!=0 or r['splitFactor']!=1]
    else: independent[name]['actions']=v['chart']['result'][0].get('events',{})
report={'code':str(CODE),'code_sha256':hashlib.sha256(CODE.read_bytes()).hexdigest(),'fixture':str(FIX),'fixture_sha256':hashlib.sha256(FIX.read_bytes()).hexdigest(),'scale':scale,'rows':len(dates),'independent_sources':independent,'cases':results,'verification_boundary':'Real fetch_yahoo and _fetch_us_yahoo called; HTTP frozen fixture only; Stooq spy returns actual valid control; Nasdaq gap helper isolated; no network/accounts/strategy backtest/deployment.'}
target=OUT/('results_after.json' if len(sys.argv)>1 else 'results_before.json')
target.write_text(json.dumps(report,ensure_ascii=False,indent=2,allow_nan=False),encoding='utf-8')
print(json.dumps({'code_sha256':report['code_sha256'],'scale':scale,'cases':results},ensure_ascii=False,indent=2))
