import contextlib, copy, io, json, pathlib, runpy, sys
from unittest.mock import patch
import numpy as np
import pandas as pd
HERE=pathlib.Path(__file__).resolve().parent
sys.argv=[str(HERE/'check_ca.py'),str(HERE.parent/'after/mnt_bot V 8.0 plus.py')]
with contextlib.redirect_stdout(io.StringIO()): g=runpy.run_path(str(HERE/'check_ca.py'))
m=g['m']; original=g['original']; payload=g['payload']; dates=g['dates']; control=g['control']; forbidden=g['forbidden']; response=g['response']
raw_frame=pd.DataFrame({'open':original['indicators']['quote'][0]['open'],'close':original['indicators']['quote'][0]['close']},index=dates)
results={}
def reset():
    m._V80_INTEGRITY_GENERATION=0; m._V80_INTEGRITY_CONFLICTS.clear(); m._V80_INTEGRITY_COVERAGE.clear()
def invoke(p=None,network=False,broken_json=False,start='2003-01-01'):
    fallback=[]; gap_calls=[]
    def stooq(*a,**kw):
        fallback.append(True);f=control.copy();f.attrs={};return f
    def gap(*a,**kw):gap_calls.append(True);return raw_frame.copy()
    class Broken:
        status_code=200
        def json(self):raise ValueError('deliberately malformed HTTP-200 JSON')
    ret=Broken() if broken_json else response(payload if p is None else p)
    with patch.object(m.requests.sessions.Session,'request',side_effect=forbidden),patch.object(m._session,'get',side_effect=m.requests.exceptions.Timeout('offline network failure') if network else None,return_value=ret),patch.object(m,'_fetch_us_stooq',side_effect=stooq),patch.object(m,'_fetch_us_nasdaq_history',side_effect=gap),patch.object(m.time,'sleep',return_value=None):
        try:
            frame,source=m.fetch_yahoo('KMLM',start)
            out={'status':'returned','source':source,'rows':len(frame) if frame is not None else None,'stooq_calls':len(fallback),'nasdaq_helper_calls':len(gap_calls)}
            if frame is not None:out['missing_dates']=[str(d.date()) for d in dates.difference(frame.index)]
        except Exception as e:out={'status':'raised','error_type':type(e).__name__,'message':str(e),'stooq_calls':len(fallback),'nasdaq_helper_calls':len(gap_calls)}
    out['quarantined']=m._v80_integrity_pending('KMLM'); return out
def gap_payload(day,value=None):
    p=copy.deepcopy(payload);r=p['chart']['result'][0];i=dates.get_loc(pd.Timestamp(day))
    r['indicators']['quote'][0]['close'][i]=value;r['indicators']['adjclose'][0]['adjclose'][i]=value
    return p
for day in ['2023-06-01','2024-12-16','2024-12-17','2025-12-19','2025-12-22']:
    reset();results['paired_gap_'+day]=invoke(gap_payload(day))
reset();p=gap_payload('2023-06-01');r=p['chart']['result'][0];a=r['indicators']['adjclose'][0]['adjclose']
for i in np.flatnonzero(dates<=pd.Timestamp('2023-06-01')):
    if a[i] is not None:a[i]*=g['scale']
results['nonaction_gap_hiding_seam']=invoke(p)
for as_float32 in [False,True]:
    reset();p=copy.deepcopy(payload);r=p['chart']['result'][0];a=np.array(r['indicators']['adjclose'][0]['adjclose'],float);raw=np.array(r['indicators']['quote'][0]['close'],float)
    for day,cash in [('2024-12-17',0.2301),('2025-12-22',1.3035)]:
        ix=dates.get_loc(pd.Timestamp(day));observed=(a[ix-1]/raw[ix-1])/(a[ix]/raw[ix]);a[:ix]*=(1-cash/raw[ix-1])/observed
    r['indicators']['adjclose'][0]['adjclose']=list(a.astype(np.float32).astype(float) if as_float32 else a)
    results['independent_verified_later_amounts_float32_'+str(as_float32)]=invoke(p)
reset();p=copy.deepcopy(payload);r=p['chart']['result'][0];keep=np.flatnonzero(dates>=pd.Timestamp('2023-01-03'))
for block in [r]+r['indicators']['quote']+r['indicators']['adjclose']:
    for key,value in list(block.items()):
        if isinstance(value,list) and len(value)==len(dates):block[key]=[value[i] for i in keep]
results['postevent_only_slice_valid_control']=invoke(copy.deepcopy(p),start='2023-01-03')
rd=pd.to_datetime(r['timestamp'],unit='s',utc=True).tz_localize(None).normalize()
for i in np.flatnonzero(rd<=pd.Timestamp('2023-06-01')):r['indicators']['adjclose'][0]['adjclose'][i]*=g['scale']
results['postevent_only_slice_hiding_suffix_seam']=invoke(p,start='2023-01-03')
reset();results['network_no_conflict']=invoke(network=True)
reset();results['malformed_http200_json_no_conflict']=invoke(broken_json=True)
reset();results['recovery_control_seed']=invoke()
p=copy.deepcopy(payload);p['chart']['result'][0]['indicators']['adjclose'][0]['adjclose'].pop()
results['recovery_trigger_conflict']=invoke(p)
results['recovery_network_cannot_escape']=invoke(network=True)
results['recovery_full_yahoo']=invoke()
results['post_recovery_network_fallback_allowed']=invoke(network=True)
reset();p=copy.deepcopy(payload);p['chart']['result'][0]['indicators']['adjclose'][0]['adjclose'].pop()
results['first_conflict_without_prior_coverage']=invoke(p)
p=copy.deepcopy(payload);r=p['chart']['result'][0];keep=np.flatnonzero(dates>=pd.Timestamp('2021-01-04'))
for block in [r]+r['indicators']['quote']+r['indicators']['adjclose']:
    for key,value in list(block.items()):
        if isinstance(value,list) and len(value)==len(dates):block[key]=[value[i] for i in keep]
results['first_recovery_truncated_before_anchor']=invoke(p,start='2021-01-04')
results['first_recovery_complete_yahoo']=invoke()
(HERE/'boundary_results_after.json').write_text(json.dumps(results,ensure_ascii=False,indent=2),encoding='utf8')
print(json.dumps(results,ensure_ascii=False,indent=2))
